## Copyright (C) 2015 bedder
## 
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## Author: bedder <bedder@BEDDER-THINKPAD>
## Created: 2015-06-16

function [time, algorithm, player, data] = ParseFileName (fileName)
    regexStr = '([\d\.]*)-class battle.controllers.([\w\.]*)-(\d)-(\w*).csv';
    results = regexp(fileName, regexStr, 'tokens');

    if ~isempty(results)
        time      = results{1}{1};
        algorithm = results{1}{2};
        player    = results{1}{3};
        data      = results{1}{4};
    end
endfunction