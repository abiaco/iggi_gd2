function [out, algorithms] = LoadData(directory)
	# Setup files
    filesScore = dir(fullfile(directory, '*score.csv'));
    filesVelocity = dir(fullfile(directory, '*velocity.csv'));
    filesMissiles = dir(fullfile(directory, '*missiles.csv'));

    # Get test conditions
    [timestamps, algorithms] = FindData(directory, filesScore);

    # Init data structure
    out = cell(length(algorithms));
    for i=1:length(algorithms)^2
    	out(i) = {cell(4, 1)};
    end


    for time=timestamps
    	tmp = dir(fullfile(directory, [time{1}, '*-0-score.csv']));
    	alg1 = regexp(tmp(1).name, '.*controllers\.([\w\.]*)-0.*', 'tokens');
    	alg1 = alg1{1}{1};
    	alg1index = strmatch(alg1, algorithms);

    	tmp = dir(fullfile(directory, [time{1}, '*-1-score.csv']));
    	alg2 = regexp(tmp(1).name, '.*controllers\.([\w\.]*)-1.*', 'tokens');
    	alg2 = alg2{1}{1};
    	alg2index = strmatch(alg2, algorithms);

    	out = PopulateData(out, directory, time{1}, alg1, alg1index, alg2, alg2index);
    end
endfunction