function [winRatio] = GetWinComparison(data, alg1index, alg2index)
	if alg1index <alg2index
		winRatio = mean(cell2mat(data{alg1index, alg2index}{4}));
	else
		if alg1index > alg2index
			winRatio = 1 - mean(cell2mat(data{alg2index, alg1index}{4}));
		else
			winRatio = 0;
		end
	end
endfunction