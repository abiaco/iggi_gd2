function [scoreProfile, missileProfile, velocityMean, velocityStd] = GetAlgorithmMetrics(data, algIndex)
	scoreProfile = zeros(1, 100);
	missileProfile = zeros(1, 100);
	velocity = [];

	for other = algIndex+1:size(data, 1)
		for iter =1:30
			scoreProfile = scoreProfile .+ data{algIndex, other}{1}{iter}(1, :);
			velocity = [velocity, data{algIndex, other}{2}{iter}(1, :)];
			missileProfile = missileProfile .+ data{algIndex, other}{3}{iter}(1, :);
		end
	end
	for other = 1:algIndex-1
		for iter =1:30
			scoreProfile = scoreProfile .+ data{other, algIndex}{1}{iter}(2, :);
			velocity = [velocity, data{other, algIndex}{2}{iter}(2, :)];
			missileProfile = missileProfile .+ data{other, algIndex}{3}{iter}(2, :);
		end
	end

	velocityMean = mean(velocity);
	velocityStd = std(velocity);

	scoreProfile = scoreProfile;
	missileProfile = missileProfile / length(velocity);
endfunction