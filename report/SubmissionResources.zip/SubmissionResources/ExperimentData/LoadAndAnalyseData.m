function [data, algorithms] = LoadAndAnalyseData(directory)
	[data, algorithms] = LoadData(directory);

	# Between-alg comparisons
	for i=1:length(algorithms)
		for j = i+1:length(algorithms)
			winRatio = GetWinComparison(data, i, j);
			[algorithms{i}, ' VS ', algorithms{j}]
			winRatio
		end
	end

	# Within-alg comparisons
	scoreFigure = figure();
	hold on;
	missileFigure = figure();
	hold on;

	scores = cell(0);
	colours = 'rgbk';
	for i=1:length(algorithms)
		[scoreProfile, missileProfile, velocityMean, velocityStd] = GetAlgorithmMetrics(data, i);

		scoreFigure = figure(scoreFigure);
		plot(10:10:1000, scoreProfile, colours(i));

		missileFigure = figure(missileFigure);
		plot(10:10:1000, missileProfile, colours(i));

		algorithms{i}
		velocityMean
		velocityStd
	end

	figure(scoreFigure);
	title('Average score');
	xlabel('Ticks');
	ylabel('Score');
	legend(algorithms, 'Location', 'northwest');
	set(gcf, 'papersize', [6.4, 4.8]);
	set(gcf, 'paperposition', [0, 0, 6.4, 4.8]);
	print('score_X.pdf');

	figure(missileFigure);
	title('Missiles remaining');
	xlabel('Ticks');
	ylabel('Proportion of missiles remaining');
	legend(algorithms, 'Location', 'northeast');
	set(gcf, 'papersize', [6.4, 4.8]);
	set(gcf, 'paperposition', [0, 0, 6.4, 4.8]);
	print('missiles_X.pdf');

	hold off;

endfunction