function out = PopulateData(out, dir, time, alg1, alg1index, alg2, alg2index)
	# Score
	score = [csvread([dir, '/', time, '-class battle.controllers.', alg1, '-0-score.csv']) ;
	         csvread([dir, '/', time, '-class battle.controllers.', alg2, '-1-score.csv'])];
	for i=size(score, 2)+1:101
		score(:,i) = score(:, i-1);
	end
	out{alg1index, alg2index}{1}{end+1} = score(:, 1:end-1);

	# Velocity
	velocity = [csvread([dir, '/', time, '-class battle.controllers.', alg1, '-0-velocity.csv']) ;
	            csvread([dir, '/', time, '-class battle.controllers.', alg2, '-1-velocity.csv'])];
	for i=size(velocity, 2)+1:101
		velocity(:,i) = velocity(:, i-1);
	end
	out{alg1index, alg2index}{2}{end+1} = velocity(:, 1:end-1);

	# Missiles
	missiles = [csvread([dir, '/', time, '-class battle.controllers.', alg1, '-0-missiles.csv']) ;
	            csvread([dir, '/', time, '-class battle.controllers.', alg2, '-1-missiles.csv'])];
	for i=size(missiles, 2)+1:101
		missiles(:,i) = missiles(:, i-1);
	end
	out{alg1index, alg2index}{3}{end+1} = missiles(:, 1:end-1);

	# Wins
	if score(1,end-1) > score(2, end-1)
		out{alg1index, alg2index}{4}{end+1} = 0;
	else
		out{alg1index, alg2index}{4}{end+1} = 1;
	end
	
endfunction